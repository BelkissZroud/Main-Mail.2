
import java.io.IOException;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GestorURL {

    private URL dirweb;
    private String codigoFuente = "";
    private URLConnection urlc;
    private HttpURLConnection hc;

    public GestorURL(String url) throws MalformedURLException {
        dirweb = new URL(url);
        hc = new HttpURLConnection(dirweb) {

            @Override
            public void disconnect() {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            @Override
            public boolean usingProxy() {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            @Override
            public void connect() throws IOException {
                throw new UnsupportedOperationException("Not supported yet.");
            }
        };
        urlc = new URLConnection(dirweb) {

            @Override
            public void connect() throws IOException {
                throw new UnsupportedOperationException("Not supported yet.");
            }
        };
    }

    public String getCodigoFuente() {

        urlc.getContentEncoding();
        hc.getContentEncoding();



        try {
            dirweb.getContent();
        } catch (IOException ex) {
            Logger.getLogger(GestorURL.class.getName()).log(Level.SEVERE, null, ex);
        }
        dirweb.getDefaultPort();
        dirweb.getFile();
        dirweb.getHost();
        dirweb.getPath();
        dirweb.getPort();
        dirweb.getProtocol();
        dirweb.getQuery();
        dirweb.getRef();
        dirweb.getUserInfo();
        dirweb.toExternalForm();
        dirweb.toString();
        return codigoFuente;
    }
}
