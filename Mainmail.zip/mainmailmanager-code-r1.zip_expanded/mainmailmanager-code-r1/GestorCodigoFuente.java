
import java.util.*;

public class GestorCodigoFuente {

    private String codigoFuente,  lineasDelCodigoFuente[],  servidor,  links[];
    private char charDeLinea[];
    private int contadorLinks = 0,  inicioLink = 0,  finLink = 0;
    private StringTokenizer st;

    public GestorCodigoFuente(String codigoFuente, String servidor) {
        this.codigoFuente = codigoFuente;
        if (servidor.equals("")) {
            servidor = "http://";
        } else {
            this.servidor = servidor;
        }
        st = new StringTokenizer(codigoFuente);
        lineasDelCodigoFuente = codigoFuente.split("\n");
        links = new String[lineasDelCodigoFuente.length];
    }

    private void getLinks() {
        for (int i = 0; st.hasMoreElements(); i++) {//J'analyse chaque ligne du code source pour voir si elle a le lien du serveur

            String linea = st.nextToken();
            if (linea.contains(servidor)) {//J'analyse la ligne qui contient le nom du serveur
                inicioLink = 0;
                finLink = linea.length();
                charDeLinea = linea.trim().toCharArray();
                for (int j = 0; j < charDeLinea.length; j++) {
                    char charlinea = charDeLinea[j];
                    if (charlinea == '<' || charlinea == '\"') {
                        if (inicioLink != 0) {//Si ya se guardo el primer caracter del link salgo del for de caracteres
                            finLink = j;
                            break;
                            //j = charDeLinea.length;
                        }
                    }
                    if (charlinea == '>' || charlinea == '\"' || charlinea == '=') {
                        try {
                            if (charDeLinea[j + 1] == 'h' &&
                                    charDeLinea[j + 2] == 't' &&
                                    charDeLinea[j + 3] == 't' &&
                                    charDeLinea[j + 4] == 'p') {
                                inicioLink = j + 1;
                            }
                        } catch (Exception e) {
                        }
                    }
                }

                if (!existe(linea.substring(inicioLink, finLink))) {//Si NO existe la agrego, para no tener links repetidos
                    links[contadorLinks++] = linea.substring(inicioLink, finLink);
                }
            }//FIN de analizar la linea que contiene el nombre del servidor
        }//FIN del analisis de cada linea del codigo fuente
    }

    private boolean existe(String link) {
        for (int i = 0; i < links.length; i++) {
            String l = links[i];
            if (l!=null && l.equals(link)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        getLinks();
        String retorno = "";
        for (int i = 0; i <
                links.length; i++) {
            String link = links[i];
            if (link != null) {
                retorno += link + "\n";
            }
        }
        return retorno;
    }
}